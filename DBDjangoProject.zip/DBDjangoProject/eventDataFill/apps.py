from django.apps import AppConfig


class EventdatafillConfig(AppConfig):
    name = 'eventDataFill'
