from django.conf import settings
from django.conf.urls.static import static

from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^AddEventConsumerType/$', views.addEventConsumerType, name='eventConsumerType'),
    url(r'^AddEventSubType/$', views.addEventSubType, name='eventSubType'),
    url(r'^AddEventConsumer/$', views.addEventConsumer, name='eventConsumer'),
    url(r'^AddEventType/$', views.create_addEventType, name='eventType'),
    # url(r'^AddEventType/$', views.create_addEventType, name='eventType'),
]

if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)