# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey has `on_delete` set to the desired behavior.
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models
from datetime import datetime

class Eventtype(models.Model):
    id = models.CharField(primary_key=True, max_length=255)
    name = models.CharField(db_column='Name', max_length=255)  # Field name made lowercase.
    description = models.CharField(db_column='Description', max_length=255, blank=True, null=True)  # Field name made lowercase.
    createdby = models.CharField(max_length=255, blank=True, null=True)
    modifiedby = models.CharField(max_length=255, blank=True, null=True)
    createdts = models.DateTimeField(default=datetime.now)
    lastmodifiedts = models.DateTimeField(default=datetime.now)
    synctimestamp = models.DateTimeField(default=datetime.now)
    softdeleteflag = models.IntegerField(blank=True, null=True, default=0)

    class Meta:
        db_table = 'eventtype'


class Eventsubtype(models.Model):
    id = models.CharField(primary_key=True, max_length=255)
    eventtypeid = models.ForeignKey('Eventtype', models.DO_NOTHING, db_column='eventtypeid', null=False)
    name = models.CharField(db_column='Name', max_length=255, blank=True, null=True)  # Field name made lowercase.
    description = models.CharField(db_column='Description', max_length=255, blank=True, null=True)  # Field name made lowercase.
    createdby = models.CharField(max_length=255, blank=True, null=True, default='konydbp')
    modifiedby = models.CharField(max_length=255, blank=True, null=True)
    createdts = models.DateTimeField(default=datetime.now)
    lastmodifiedts = models.DateTimeField(default=datetime.now)
    synctimestamp = models.DateTimeField(default=datetime.now)
    softdeleteflag = models.IntegerField(blank=True, null=True, default=0)

    class Meta:
        db_table = 'eventsubtype'
        unique_together = (('id', 'eventtypeid'),)


class Eventconsumer(models.Model):
    serviceid = models.CharField(db_column='ServiceId', primary_key=True, max_length=50 ,default='Alerts')  # Field name made lowercase.
    operationid = models.CharField(db_column='OperationId', max_length=50, default='SOME STRING')  # Field name made lowercase.
    batchlimit = models.IntegerField(db_column='BatchLimit', default=20)  # Field name made lowercase.
    lasteventid = models.IntegerField(db_column='LastEventId', default=0)  # Field name made lowercase.

    class Meta:
        db_table = 'eventconsumer'
        unique_together = (('serviceid', 'operationid'),)


class Eventconsumertypes(models.Model):
    serviceid = models.CharField(db_column='ServiceId', primary_key=True, max_length=50, default='Alerts')  # Field name made lowercase.
    operationid = models.CharField(db_column='OperationId', max_length=50, default='pushAlerts')  # Field name made lowercase.
    eventtype = models.CharField(db_column='EventType', max_length=20, default='LOGIN')  # Field name made lowercase.

    class Meta:
        db_table = 'eventconsumertypes'
        unique_together = (('serviceid', 'operationid', 'eventtype'),)
