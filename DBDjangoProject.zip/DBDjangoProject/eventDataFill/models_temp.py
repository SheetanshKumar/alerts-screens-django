from django.db import models

# Create your models here.


class EventType(models.Model):
    id = models.CharField(max_length=255, primary_key=True)
    name = models.CharField(max_length=255)


class EventSubType(models.Model):
    id = models.CharField(max_length=255, primary_key=True)
    name = models.CharField(max_length=255)
    eventtypeid = models.ForeignKey(EventType, on_delete=models.SET_NULL, null=True)


class EventConsumer(models.Model):
    serviceId = models.CharField(max_length=255)
    operationId = models.CharField(max_length=255)
    batchlimit = models.PositiveIntegerField()


class EventConsumerTypes(models.Model):
    serviceId = models.CharField(max_length=255)
    operationId = models.CharField(max_length=255)
    eventType = models.CharField(max_length=255)


