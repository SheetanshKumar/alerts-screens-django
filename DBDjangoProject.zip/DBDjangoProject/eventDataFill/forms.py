from django import forms
from . import models


class AddEventType(forms.ModelForm):
    class Meta:
        model = models.Eventtype
        fields = ['id', 'name', 'description', 'createdby']
    def clean_id(self):
        id = self.cleaned_data['id']
        return id.upper()


class AddEventConsumer(forms.ModelForm):
    class Meta:
        model = models.Eventconsumer
        fields = ['serviceid', 'operationid', 'batchlimit']


class AddEventSubType(forms.ModelForm):
    class Meta:
        model = models.Eventsubtype
        fields = ['eventtypeid','id', 'name', 'description', 'createdby']

    def clean_id(self):
        id = self.cleaned_data['id']
        return id.upper()


class AddEventConsumerType(forms.ModelForm):
    class Meta:
        model = models.Eventconsumertypes
        fields = ['serviceid', 'operationid', 'eventtype']

    def clean_id(self):
        id = self.cleaned_data['id']
        return id.upper()

