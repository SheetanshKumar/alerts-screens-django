from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.views.decorators.csrf import csrf_protect
from django.views import View
from .models import *
from . import forms


# @csrf_protect
# class CreateEventType(View):
#
#     def get(self, request):
#         template_name = 'events/AddEventType.html'
#         form = forms.AddEventType()
#         return render(request, template_name, {'form': form})
#
#     def post(self, request):
#         form = forms.AddEventType(request.POST)
#         if form.is_valid():
#             form.save(commit=True)
#             return redirect('/eventDataFill/AddEventType')
#         else:
#             return HttpResponse('Form_Invalid')


@csrf_protect
def addEventConsumerType(request):
    template_name = 'events/AddEventConsumerType.html'

    eventtypeid = Eventtype.objects.all()
    eventconsumer = Eventconsumer.objects.all()
    if request.method == 'POST':
        form = forms.AddEventConsumerType(request.POST)
        print(form.is_valid())
        form.save(commit=True)
        if form.is_valid():
            form.save(commit=True)
            return redirect('/eventDataFill/AddEventConsumerType')
    else:
        form = forms.AddEventConsumerType()
    return render(request, template_name, {'form': form, 'eventtypeid': eventtypeid, 'eventconsumer': eventconsumer})

@csrf_protect
def addEventSubType(request):
    template_name = 'events/AddEventSubType.html'

    eventtypeid = Eventtype.objects.all()


    if request.method == 'POST':
        print("hellotherer")
        form = forms.AddEventSubType(request.POST)
        print(form.is_valid())

        if form.is_valid():
            form.save(commit=True)
            return redirect('/eventDataFill/AddEventSubType')
    else:
        form = forms.AddEventSubType()
    return render(request, template_name, {'form': form, 'eventtypeid': eventtypeid})


@csrf_protect
def addEventConsumer(request):
    template_name = 'events/AddEventConsumer.html'

    if request.method == 'POST':
        form = forms.AddEventConsumer(request.POST)
        if form.is_valid():
            form.save(commit=True)
            return redirect('/eventDataFill/AddEventConsumer')
    else:
        form = forms.AddEventConsumer()
    return render(request, template_name, {'form': form})

@csrf_protect
def create_addEventType(request):
    template_name = 'events/AddEventType.html'

    if request.method == 'POST':
        form = forms.AddEventType(request.POST)
        if form.is_valid():
            form.save(commit=True)
            return redirect('/eventDataFill/AddEventType')
    else:
        form = forms.AddEventType()
    return render(request, template_name, {'form': form})
