from django.http import HttpResponse
from django.template import loader

from django.shortcuts import render_to_response
from django.template.context import RequestContext
def index(request):
    # getting our template
    template = loader.get_template("AddEventType.html")
    context = {
        'name': 'Sheetansh Kumar',
        'fname': 'Ranjeet Kumar',
        'course': 'Python Django Framework',
        'address': 'Kadru, Ranchi, India',
    }

    # rendering the template in HttpResponse
    return HttpResponse(template.render(context, request))
